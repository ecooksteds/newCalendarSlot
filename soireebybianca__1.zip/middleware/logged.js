module.exports = require("connect-ensure-login").ensureLoggedIn("/user/login");
