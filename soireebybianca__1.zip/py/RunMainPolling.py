from Polling import Polling
polling = Polling(1)

print(polling.getOpenSlot())